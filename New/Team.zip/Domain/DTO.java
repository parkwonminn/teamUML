package Team.Domain;

public class DTO {

}
