package Team.Domain;

import java.sql.*;

public class MemDAO {
	String id = "SYSTEM";
	String pw = "1234";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	
	//DB연결객체 관련 참조변수
	Connection conn = null;				//DB연결객체용
	PreparedStatement pstmt = null;		//SQL쿼리 전송용 객체
	ResultSet rs = null;				//쿼리결과(Select결과) 수신용
	
	private static MemDAO instance;
	public static MemDAO getInstance()
	{
		if(instance == null)
			instance = new MemDAO();
		return instance;
	}
	
	private MemDAO()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, id, pw);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public int Insert(MemDTO dto)
	{
		int result = 0;
		try
		{
			Connection conn = DriverManager.getConnection(url, id, pw);
			PreparedStatement pstmt = conn.prepareStatement("insert into mem_tbl values(?, ?, ?, ?, ?, default, 1, 0)");
			pstmt.setString(1, dto.getID());
			pstmt.setString(2, dto.getPW());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getAddr());
			pstmt.setString(5, dto.getPhone());
			result = pstmt.executeUpdate();
			if(result != 0)
				System.out.println("Insert Success!");
			else
				System.out.println("Insert Failed..");
		} catch (Exception e) {e.printStackTrace();}
		
		return result;
	}
	
	public int Login(String userid, String userpw)
	{
		MemDTO dto = new MemDTO();
		PreparedStatement pstmt = null;
		int result = 0;
		try
		{
			pstmt = conn.prepareStatement("select * from mem_tbl where ID=?");
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			if(rs != null)
			{
				while(rs.next())
				{
					System.out.println("Loginstatus() : " + rs.getInt("loginstatus"));
					dto = new MemDTO();
					dto.setLoginstatus(rs.getInt("loginstatus"));
					if(rs.getInt("loginstatus") == 0)
					{
						pstmt = conn.prepareStatement("update mem_tbl set loginstatus=? where id=?");
						pstmt.setInt(1, 1);
						pstmt.setString(2, userid);
						result = pstmt.executeUpdate();
					}
					else
						System.out.println("[SYSTEM] 현재 로그인 상태입니다");
				}
			}
		} catch (Exception e) {e.printStackTrace();}
		finally
		{
			try
			{
				rs.close(); pstmt.close();
				}catch(Exception e) {e.printStackTrace();}
		}
		return result;
	}
	
	public int Logout(String id)
	{
		MemDTO dto = new MemDTO();
		PreparedStatement pstmt = null;
		int result = 0;
		try
		{
			pstmt = conn.prepareStatement("select loginstatus,id from mem_tbl where id=?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs != null)
			{
				rs.next();
				dto.setLoginstatus(rs.getInt("loginstatus"));
				dto.setID(rs.getString("id"));
				if(rs.getInt("loginstatus") == 1)
				{
					pstmt = conn.prepareStatement("update mem_tbl set loginstatus=? where id=?");
					pstmt.setInt(1, 0);
					pstmt.setString(2, dto.getID());
					System.out.println(rs.getInt("loginstatus"));
					result = pstmt.executeUpdate();
				}
				else {
					System.out.println("[SYSTEM] 현재 로그아웃중입니다");
				}
			}
		} catch (Exception e) {e.printStackTrace();}
		finally
		{
			try
			{rs.close(); pstmt.close();}catch(Exception e) {e.printStackTrace();}
		}

		return result;
	}
	
	public MemDTO Select(String userid)
	{
		MemDTO dto = new MemDTO();
		PreparedStatement pstmt = null;
		int result = 0;
		try
		{
			pstmt = conn.prepareStatement("select * from mem_tbl where id=?");
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			if(rs != null)
			{
				while(rs.next())
				{
					System.out.println("select 1 : " + rs.getInt("Loginstatus"));
					dto.setID(rs.getString("ID"));
					dto.setPW(rs.getString("PW"));
					dto.setName(rs.getString("name"));
					dto.setAddr(rs.getString("addr"));
					dto.setPhone(rs.getString("phone"));
					dto.setJoinDate(rs.getString("joindate"));
					dto.setPerm(rs.getInt("perm"));
					dto.setLoginstatus(rs.getInt("loginstatus"));
					System.out.println("select 2 : " + rs.getInt("Loginstatus"));
				}
			}
		} 
		catch (Exception e) {e.printStackTrace();}
		finally
		{
			try
			{
				rs.close(); pstmt.close();
				}catch(Exception e) {e.printStackTrace();}
		}
		return dto;
	}
}
