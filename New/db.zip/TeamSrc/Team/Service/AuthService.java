package Team.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Team.Domain.MemDAO;
import Team.Domain.MemDTO;

public class AuthService {

	private MemDAO dao = MemDAO.getInstance();
	
	private static AuthService instance;
	public static AuthService getInstance()
	{
		if(instance == null)
			instance = new AuthService();
		return instance;
	}
	
	public AuthService() {}
	
	public Integer LoginCheck(String id, String pw)
	{
		MemDTO dto = null;
		dto = dao.Select(id);
		System.out.println("AuthService : " + dto.getLoginstatus());
		if(id.equals(dto.getID()) && pw.equals(dto.getPW()))
		{
			dao.Login(id,pw);
			return dto.getLoginstatus();
		}
		
		else
		{
			return null;
		}
	}
	

}
