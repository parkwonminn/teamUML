package Team.Controller;

import Team.Domain.DTO;

public interface SubController {
	
	Object execute(int SN, DTO dto);
}
